
import LoginPage from "./LoginPage";


function App() {
  return (
    <div className="App">
      
      <LoginPage></LoginPage>
     
    </div>

  );
}

export default App;
