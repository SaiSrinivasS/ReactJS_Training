import React, { useState, useEffect } from 'react'

const LoginPage = () => {
 
    const [userName, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [registeredUsers, setRegisteredUsers] = useState([])
    
    useEffect(() => {
        // Fetch the data from the JSON server
        const fetchUsers = async () => {
          try {
            const response = await fetch("http://localhost:8000/registeredUsers");
            if (!response.ok) {
              throw new Error("Failed to fetch users");
            }
            const data = await response.json();
            setRegisteredUsers(data);
          } catch (APIerror) {
            console.error("Error fetching users:", APIerror);
          }
        };
        fetchUsers();
        }, []);

       
    const validateCredentials = (e) => {
        e.preventDefault();
        console.log(validateForm());
        if (validateForm()) {
            const Requestingnuser = { userName, password }
            console.log(Requestingnuser)
        }
    };
 
    const [errors, setErrors] = useState({
        userName: '',
        password: '',
    });
 
    const validateForm = () => {
        let valid = true;
        //const { name, email, password } = formData;
        const errorsCopy = { ...errors };
 
        if (!userName.trim()) {
            errorsCopy.userName = 'Username is required';
            valid = false;
        }
        // else if(userName.length<=6){
        //     errorsCopy.firstName = 'First Name should have more than six characters';
        //     valid = false;
        // }
         else {
            errorsCopy.userName = '';
        }
 
        if (!password.trim()) {
            errorsCopy.password = 'Password is required';
            valid = false;
        } else {
            errorsCopy.password = '';
        }

        console.log(...registeredUsers)
        setErrors(errorsCopy);
        return valid;
    };
 
    return (
        <div>
            <br /><br />
            <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                        <h2 className='text-center'>Login</h2>
                        <div className="card-body">
                            <form>
                                <div className="form-group mb-2">
                                    <label className="form-label"> Username :</label>
                                    <input
                                        type="text"
                                        placeholder="Enter username"
                                        name="userName"
                                        className={`form-control ${errors.userName ? 'is-invalid' : ''}`}
                                        value={userName}
                                        onChange={(e) => setUsername(e.target.value)}
                                    >
                                    </input>
                                    {errors.userName && <div className="invalid-feedback">{errors.userName}</div>}
                                </div>
 
                                <div className="form-group mb-2">
                                    <label className="form-label"> Password :</label>
                                    <input
                                        type="text"
                                        placeholder="Enter password"
                                        name="password"
                                        className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    >
                                    </input>
                                    {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                                </div>
 
                                <button className="btn btn-success" onClick={(e) => validateCredentials(e)}>Login </button>
                                {/* <Link to="/employees" className="btn btn-danger"> Cancel </Link> */}
                            </form>
 
                        </div>
                    </div>
                </div>
 
            </div>
 
        </div>
    )
};
 
export default LoginPage