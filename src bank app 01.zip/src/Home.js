import React,{createContext, useContext} from 'react'
import {Route,Routes} from "react-router-dom";
import Transfer from "./Transfer";
import NavBar from "./NavBar";



function Home() {
  //const UserSessionContext = createContext()
 // const {IsSessionValid, validateSession} = useContext(UserSessionContext)
  return (
    <div>
    {/* <header >
        <NavBar></NavBar>
        <h1>Welcome to ABC bank</h1>
        <h2>Home page</h2>
       
    </header> */}
     {/* <Routes>
            <Route path = "/" element = {< />}></Route>
            <Route path = "/Transfer" element = {<Transfer/>}></Route>
            {/* <Route path = "/Logout" element = {<Home/>}></Route> 
        </Routes> */}
    </div>
  )
}

export default Home
