import React, { useState, useEffect, createContext, useContext } from 'react'
//import { Route, Routes, useNavigate } from 'react-router-dom';
// import Home from './Home';
// import Transfer from './Transfer';
// import NavBar from './NavBar';
import AccountDetails from './AccountDetails';
//const UserSessionContext = createContext()

export const HomePage = () => {
 
    const [userName, setUsername] = useState('')
    const [password, setPassword] = useState('')
    // const [IsUserLoggedIn, setUserLoggedIn] = useState(true)
    const [IsSessionValid, setSessionValidity] = useState(false)
    const [registeredUsers, setRegisteredUsers] = useState([])
    
    
    //const redirect = useNavigate();
  
    
    useEffect(() => {
        // Fetch the data from the JSON server
        const fetchUsers = async () => {
          try {
            const response = await fetch("http://localhost:8000/registeredUsers");
            if (!response.ok) {
              throw new Error("Failed to fetch users");
            }
            const data = await response.json();
            setRegisteredUsers(data);
            //setSessionValidity(false)
          } catch (APIerror) {
            console.error("Error fetching users:", APIerror);
          }
        };
        fetchUsers();
        }, []);   

    const validateCredentials = (e) => {
        e.preventDefault();
        const IsFormValid = validateForm()
        console.log("Result of validation: ",IsFormValid);
        if (IsFormValid) {  
            setSessionValidity(true)
        }
        else{
            setSessionValidity(false)
        }
    };
 
    const [errors, setErrors] = useState({
        userName: '',
        password: '',
        errorMessage: ''
    });
 
    const validateForm = () => {
        let valid = true;
        //const { name, email, password } = formData;
        const errorsCopy = { ...errors };
        const user = registeredUsers.find(
            (user) => user.username === userName && user.password === password
          );
      
        //Check username and password are valid  
        if (!userName.trim()) {
            errorsCopy.userName = 'Username is required';
            valid = false;
        }        
         else {
            errorsCopy.userName = '';
        }
 
        if (!password.trim()) {
            errorsCopy.password = 'Password is required';
            valid = false;
        } else {
            errorsCopy.password = '';
        }

        //Check if the username and password are correct nad matching with the DB
        // a. Find the matching username and password
        const isValidUser = registeredUsers.find(
            (user) => user.email === userName && user.password === password
          );
        if (isValidUser) {            
            errorsCopy.errorMessage = '';
            //console.log("Logged in successfully");
          } 
          else {
            errorsCopy.errorMessage = 'Invalid username or password';
            valid = false;
            //console.log("Invalid username or password");
          }
        // set the errors back to the component state        
        setErrors(errorsCopy);
        return valid; //returns true is credentials are valid returns false if not
    };
 
    const handleLogout=()=>{
        alert("Do you want to logout?")
        setSessionValidity(false)
        setUsername('')
        setPassword('')
        
    }
    // function validateSession(){
    //     setSessionValidity(true)
    //     console.log("from validate session - IsSessionValid: ",IsSessionValid)
    //     return(
    //         // <UserSessionContext.Provider value={{IsSessionValid,validateSession}}>
    //         //     {/* <h1>{`Hello ${IsSessionValid}`}</h1> */}
    //         //     <AccountDetails/>
    //         // </UserSessionContext.Provider>
    //     )
    // }
    // function inValidateSession(){
    //     setSessionValidity(false)
    //     console.log("from invalidate session - IsSessionValid: ",IsSessionValid)
    //     return(
    //         // <UserSessionContext.Provider value={{IsSessionValid,inValidateSession}}>
    //         //     <div>
    //         //         <h1>{`Hello ${IsSessionValid}`}</h1>
    //         //         <AccountDetails/>
    //         //     </div>
    //         // </UserSessionContext.Provider>
    //     )
    // }
    return (
        <div>
             <header >
                <h1>Welcome to ABC bank</h1>
                <h2>Home page</h2>
                {/* {IsSessionValid&&<button className="btn btn-success" onClick={()=>{return(setSessionValidity(false))}}>Logout</button>} */}
                {IsSessionValid&&<button className="btn btn-success" onClick={()=>{return(handleLogout())}}>Logout</button>}
            </header>
            <br /><br />
            <div className="container">
                {!IsSessionValid&&
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            <h2 className='text-center'>Login</h2>
                            <div className="card-body">            
                                <form>
                                    {/* Error message */}
                                    {errors.errorMessage && <div className="form-group mb-2">{errors.errorMessage}</div>}
                                    
                                    <div className="form-group mb-2">
                                        <label className="form-label"> Username :</label>
                                        <input
                                            type="text"
                                            placeholder="Enter username"
                                            name="userName"
                                            className={`form-control ${errors.userName ? 'is-invalid' : ''}`}
                                            value={userName}
                                            onChange={(e) => setUsername(e.target.value)}
                                        >
                                        </input>
                                        {errors.userName && <div className="invalid-feedback">{errors.userName}</div>}
                                    </div>
    
                                    <div className="form-group mb-2">
                                        <label className="form-label"> Password :</label>
                                        <input
                                            type="password"
                                            placeholder="Enter password"
                                            name="password"
                                            className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                        >
                                        </input>
                                        {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                                    </div>
    
                                    <button className="btn btn-success" onClick={(e) => validateCredentials(e)}>Login </button>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                }  
                {IsSessionValid&&
                    <div className="row">
                        <AccountDetails userEmail = {userName}  ></AccountDetails>
                        
                    </div>
                    
                }
                
                
            
            </div>
           
        </div>
    )   



};

// export function getCurrentState(){
//     return(UserSessionContext)
// }