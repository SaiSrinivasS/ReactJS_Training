import React, {useContext, useEffect, useState} from 'react'
//import {getCurrentState} from './HomePage.js'


const AccountDetails = props => {
    // const {IsSessionValid, validateSession} = useContext(getCurrentState.IsSessionValid)
    const UserEmailID = props.userEmail
    const [registeredUsers, setRegisteredUsers] = useState([])
    useEffect(() => {
        // Fetch the data from the JSON server
        const fetchUsers = async () => {
          try {
            const response = await fetch("http://localhost:8000/registeredUsers");
            if (!response.ok) {
              throw new Error("Failed to fetch users");
            }
            const data = await response.json();
            setRegisteredUsers(data);
            //setSessionValidity(false)
          } catch (APIerror) {
            console.error("Error fetching users:", APIerror);
          }
        };
        fetchUsers();
        }, []);  
    const user = registeredUsers.find(
        (user) => user.email === UserEmailID
    ) 
  return (
    <div className="container">
            <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
                <h2 className='text-center'>Account Details</h2>
                <div className="card-body">            
                    <div className="form-group mb-2">
                            <label className="form-label"> Email ID: {UserEmailID}</label>
                            {/* <label className="form-label"> FirstName: {}</label> */}
                    </div>
                            
                    </div>
                </div>
            </div>
    </div>
    
  )
}

export default AccountDetails