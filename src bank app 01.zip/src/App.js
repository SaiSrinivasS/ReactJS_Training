
import Home from "./Home";
import { HomePage } from "./HomePage";



function App() {
  return (
    <div className="App">
      
      
      <HomePage></HomePage>
      
     
    </div>

  );
}

export default App;
