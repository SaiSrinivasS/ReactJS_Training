import {Link, Routes, Route} from 'react-router-dom';
import React from 'react';
import Home from './Home';
import Transfer from './Transfer';

 const NavBar=() => {
  return (
    <nav >
        <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/Transfer">Transfer</Link></li>
            {/* <li><Link to="/Logout">Logout</Link></li> */}
        
        </ul>
        
    </nav>
  )
}

export default NavBar;