import React from 'react'

function Transfer() {
  return (
    <div>
      <h2>Transer money</h2>
    </div>
  )
}

export default Transfer
