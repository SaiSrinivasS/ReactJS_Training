import React, {useContext, useEffect, useState} from 'react'
import axios from 'axios'
//import {getCurrentState} from './HomePage.js'


const AccountDetails = props => {
    // const {IsSessionValid, validateSession} = useContext(getCurrentState.IsSessionValid)
    const UserEmailID = props.userEmail
    const [registeredUsers, setRegisteredUsers] = useState([])
    const Attr = ["First Name", "Last Name", "Email", "Account Number", "Account Balance"];
    const [Requestor, setRequestor] = useState([]);
    const [Req,setReq]= useState({id:''});
    const [Res,setRes]=useState({amount:''});
    // useEffect(() => {
    //     // Fetch the data from the JSON server
    //     const fetchUsers = async () => {
    //       try {
    //         const response = await fetch("http://localhost:8000/registeredUsers");
    //         if (!response.ok) {
    //           throw new Error("Failed to fetch users");
    //         }
    //         const data = await response.json();
    //         setRegisteredUsers(data);
    //         //setSessionValidity(false)
    //       } catch (APIerror) {
    //         console.error("Error fetching users:", APIerror);
    //       }
    //     };
    //     fetchUsers();
    //     }, []);  


    useEffect(() => {
      //console.log(location)
      axios
          .get('http://localhost:8000/registeredUsers') 
          .then((res) => {
              //console.log(res.data)
              setRequestor(res.data.filter((a) =>(a.email === UserEmailID)
              ))
             // console.log(Requestor)
             // console.log(Requestor)
              Requestor.map((p)=>{
                  Req.id=p.id
                  Res.amount=p.amount
              
              })
              //console.log(Req)
              //console.log(Res)
              
          })
          .catch((err) => console.log(err));
        }, []);
    // const user = registeredUsers.find(
    //     (user) => user.email === UserEmailID
    // ) 
  return (
    <div className="container">
            <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
                <h2 className='text-center'>Account Details</h2>
                <div className="card-body">            
                    <div className="form-group mb-2">
                            {/* <label className="form-label"> Email ID: {UserEmailID}</label>
                            <label className="form-label"> FirstName: {}</label> */}
                              <table>
                <tbody>
                    <td>
                        {Attr.map((att) => (
                            <tr key={att}>{att}:</tr>
                        ))}

                    </td>
                    {Requestor.map((infos) => (
                        
                        
                        <td>
                            <tr> {infos.firstName}</tr>
                            <tr> {infos.lastName}</tr>
                            <tr> {infos.email}</tr>
                            <tr> {infos.accountNumber}</tr>
                            <tr> {infos.accountBalance}</tr>
                                                  
                            
                        </td>
                        


                    ))}


                </tbody>
                    </table>
                    </div> 
                                          
                </div>
            </div>
            </div>
            <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
                <h2 className='text-center'>Transfer</h2>
                <div className="card-body">            
                    <div className="form-group mb-2">
                       
                    </div> 
                                          
                </div>
            </div>
            </div>
                        
    </div>
    
  )
}

export default AccountDetails