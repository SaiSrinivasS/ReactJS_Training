import React, { useState } from 'react'
import Register from '../Register';

function handleSubmit(event){
    event.preventDefault();
}

const LoginPage = () => {
  
  return (
    <div className='form-group'>
        
        <form name='LoginForm' id='LoginPageForm' onSubmit={handleSubmit}>
            <table align = 'centre'>
                <tbody>
                <tr><td>User Name<input type='text' id='UName' name='UName' placeholder='Enter Username' className='form-control'/></td></tr>
                <tr><td>Password<input type='password' id='Password' name='Password' placeholder='Enter Password' className='form-control' /></td></tr>
                <tr><td><button type='submit' name ='Login' className='btn btn-primary'>Login</button></td></tr>
                </tbody>
            </table>     
        </form>   
        <Register></Register> 
    </div>
    )
}

export default LoginPage
