import React, { useState } from 'react'
import axios from "axios"

const Register = () => {
 
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    //const [RUName, setRUsername] = useState('')
    const [RPwd, setRPassword] = useState('')
    const [CRPwd, setCRPassword] = useState('')
    const [RegUsers, setUsers] = useState({
        firstName: '',
        lastName:'',
        email : '',
        password: '',
        accountNumber:'',
        accountBalance:''
        })
 
    const saveUser = (e) => {
        e.preventDefault();
        console.log(validateForm());
        if (validateForm()) {
            // const BusinessUser = { firstName, lastName, email,  RPwd, CRPwd }
            // console.log("Business user: ",BusinessUser)
            setUsers({firstName : firstName, lastName : lastName, email : email, password : RPwd , accountNumber : '103' ,accountBalance : 0})
            console.log("Reg user: ",RegUsers)
            axios
                .post("http://localhost:8000/registeredUsers", RegUsers)
                .then((res) => {
                console.log(res)
                //navigate("/");
                })
                .catch((err) => console.log(err));
        }
        

    };
 
    const [errors, setErrors] = useState({
        firstName: '',
        lastName: '',
        email: '',
        RPwd: '',
        CRPwd: ''
    });
 
    const validateForm = () => {
        let valid = true;
        //const { name, email, password } = formData;
        const errorsCopy = { ...errors };
 
        if (!firstName.trim()) {
            errorsCopy.firstName = 'First Name is required';
            valid = false;
        }
        // else if(firstName.length<=6){
        //     errorsCopy.firstName = 'First Name should have more than six characters';
        //     valid = false;
        // }
         else {
            errorsCopy.firstName = '';
        }
 
        if (!lastName.trim()) {
            errorsCopy.lastName = 'Last Name is required';
            valid = false;
        } else {
            errorsCopy.lastName = '';
        }
 
        if (!email.trim()) {
            errorsCopy.email = 'Email is required';
            valid = false;
        } else if (!/\S+@\S+\.\S+/.test(email)) {
            errorsCopy.email = 'Email is invalid';
            valid = false;
        } else {
            errorsCopy.email = '';
        }

        // if (!RUName.trim()) {
        //     errorsCopy.RUName = 'User Name is required';
        //     valid = false;
        // } else {
        //     errorsCopy.RUName = '';
        // }

        if (!RPwd.trim()) {
            errorsCopy.RPwd = 'Password is required';
            valid = false;
        } else {
            errorsCopy.RPwd = '';
        }
        
        if (!CRPwd.trim()) {
            errorsCopy.CRPwd = 'Confirm Password is required';
            valid = false;
        } 
        else if(RPwd !== CRPwd){
            errorsCopy.CRPwd = 'Password and Confirm password should match';
            valid = false;
        }
        else {
            errorsCopy.CRPwd = '';
        }
 
        setErrors(errorsCopy);
        return valid;
    };


 
    return (
        <div>
            <br /><br />
            
            <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                        <h2 className='text-center'>Register</h2>
                        <div className="card-body">
                            <form>
                                <div className="form-group mb-2">
                                    <label className="form-label"> First Name :</label>
                                    <input
                                        type="text"
                                        placeholder="Enter first name"
                                        name="firstName"
                                        className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}
                                        value={firstName}
                                        onChange={(e) => {
                                            setFirstName(e.target.value);
                                            setUsers({...RegUsers,firstname: e.target.value});
                                            //console.log("Reg user: ",RegUsers);
                                        }}
                                    >
                                    </input>
                                    {errors.firstName && <div className="invalid-feedback">{errors.firstName}</div>}
                                </div>
 
                                <div className="form-group mb-2">
                                    <label className="form-label"> Last Name :</label>
                                    <input
                                        type="text"
                                        placeholder="Enter last name"
                                        name="lastName"
                                        className={`form-control ${errors.lastName ? 'is-invalid' : ''}`}
                                        value={lastName}
                                        onChange={(e) => {
                                            setLastName(e.target.value);
                                           // setUsers({...RegUsers,lastName: e.target.value})
                                        }}
                                    >
                                    </input>
                                    {errors.lastName && <div className="invalid-feedback">{errors.lastName}</div>}
                                </div>
 
                                <div className="form-group mb-2">
                                    <label className="form-label"> Email Id :</label>
                                    <input
                                        type="email"
                                        placeholder="Enter email Id"
                                        name="email"
                                        className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    >
                                    </input>
                                    {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                                </div>

                                {/* <div className="form-group mb-2">
                                    <label className="form-label"> Username :</label>
                                    <input
                                        type="text"
                                        placeholder="Enter username"
                                        name="RegUName"
                                        className={`form-control ${errors.RUName ? 'is-invalid' : ''}`}
                                        value={RUName}
                                        onChange={(e) => setRUsername(e.target.value)}
                                    >
                                    </input>
                                    {errors.RUName && <div className="invalid-feedback">{errors.RUName}</div>}
                                </div> */}

                                <div className="form-group mb-2">
                                    <label className="form-label"> Password :</label>
                                    <input
                                        type="password"
                                        placeholder="Enter password"
                                        name="RegPassword"
                                        className={`form-control ${errors.RPwd ? 'is-invalid' : ''}`}
                                        value={RPwd}
                                        onChange={(e) => setRPassword(e.target.value)}
                                    >
                                    </input>
                                    {errors.RPwd && <div className="invalid-feedback">{errors.RPwd}</div>}
                                </div>

                                <div className="form-group mb-2">
                                    <label className="form-label"> Confirm Password :</label>
                                    <input
                                        type="password"
                                        placeholder="Re-enter password"
                                        name="CRegPassword"
                                        className={`form-control ${errors.CRPwd ? 'is-invalid' : ''}`}
                                        value={CRPwd}
                                        onChange={(e) => setCRPassword(e.target.value)}
                                    >
                                    </input>
                                    {errors.CRPwd && <div className="invalid-feedback">{errors.CRPwd}</div>}
                                </div>
 
                                <button className="btn btn-success" onClick={(e) => saveUser(e)}>Sign up </button>
                                {/* <Link to="/employees" className="btn btn-danger"> Cancel </Link> */}
                            </form>
 
                        </div>
                    </div>
                </div>
 
            </div>
            
        </div>
    )
};
 
export default Register